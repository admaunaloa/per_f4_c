#include "bsp_flash.h"
#include "bsp_gpio.h"
#include "bsp_rcc.h"

#include "stm32f4xx_hal.h"

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  volatile uint32_t tick = 0;
  static bool val = false;

  /* Set Interrupt Group Priority */
  HAL_NVIC_SetPriorityGrouping(NVIC_PRIORITYGROUP_4);

  /* Use systick as time base source and configure 1ms tick (default clock after Reset is HSI) */
  HAL_InitTick(TICK_INT_PRIORITY);

  bsp_flash_init();
  bsp_rcc_init();
  bsp_gpio_init();

  while (1)
  {
	  tick++;
      if (tick > 10000000)
	  {
		  tick = 0;
		  val = !val;
          per_gpio_set_out(bsp_gpio_led_blue(), val);
	  }
  }
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}
